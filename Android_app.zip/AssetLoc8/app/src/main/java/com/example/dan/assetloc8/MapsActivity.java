package com.example.dan.assetloc8;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.Console;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.InfoWindowAdapter {


    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setInfoWindowAdapter(this);
        /* add 3 sample markers */
        // Asset 1
        LatLng asset_1 = new LatLng(51.395982, -1.177155);
        mMap.addMarker(new MarkerOptions().position(asset_1).title("Asset #1"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(asset_1));
        // Asset 2
        LatLng asset_2 = new LatLng(51.442014, -0.997341);
        mMap.addMarker(new MarkerOptions().position(asset_2).title("Asset #2"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(asset_2));
        // Asset 1
        LatLng asset_3 = new LatLng(51.414551, -1.115221);
        mMap.addMarker(new MarkerOptions().position(asset_3).title("Asset #3"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(asset_3));
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
        //return prepareInfoView(marker);
    }

    @Override
    public View getInfoContents(Marker marker) {
        //return null;
        return prepareInfoView(marker);

    }

    private View prepareInfoView(Marker marker){
        //prepare InfoView programmatically
        String title = marker.getTitle().substring(marker.getTitle().length()-1);
        LinearLayout infoView = new LinearLayout(MapsActivity.this);
        LinearLayout.LayoutParams infoViewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoView.setOrientation(LinearLayout.HORIZONTAL);
        infoView.setLayoutParams(infoViewParams);

        if (title.equals("1")) {
            ImageView infoImageView = new ImageView(MapsActivity.this);
            Drawable drawable = getResources().getDrawable(R.mipmap.asset_2);
//        Drawable drawable = getResources().getDrawable(android.R.drawable.ic_dialog_map);
            infoImageView.setImageDrawable(drawable);
            infoView.addView(infoImageView);

            LinearLayout subInfoView = new LinearLayout(MapsActivity.this);
            LinearLayout.LayoutParams subInfoViewParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            subInfoView.setOrientation(LinearLayout.VERTICAL);
            subInfoView.setLayoutParams(subInfoViewParams);

            TextView asset_name = new TextView(MapsActivity.this);
            asset_name.setText(marker.getTitle());
            TextView route = new TextView(MapsActivity.this);
            route.setText("Route: Western Route");
            TextView site_id = new TextView(MapsActivity.this);
            site_id.setText("Site ID: 72121");
            TextView site_name = new TextView(MapsActivity.this);
            site_name.setText("Site name: BHL - 037.1496 - Brick PSP");
            subInfoView.addView(asset_name);
            subInfoView.addView(route);
            subInfoView.addView(site_id);
            subInfoView.addView(site_name);
            infoView.addView(subInfoView);
        }
        else if (title.equals("2")){
            ImageView infoImageView = new ImageView(MapsActivity.this);
            Drawable drawable = getResources().getDrawable(R.mipmap.asset_9);
//        Drawable drawable = getResources().getDrawable(android.R.drawable.ic_dialog_map);
            infoImageView.setImageDrawable(drawable);
            infoView.addView(infoImageView);

            LinearLayout subInfoView = new LinearLayout(MapsActivity.this);
            LinearLayout.LayoutParams subInfoViewParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            subInfoView.setOrientation(LinearLayout.VERTICAL);
            subInfoView.setLayoutParams(subInfoViewParams);

            TextView asset_name = new TextView(MapsActivity.this);
            asset_name.setText(marker.getTitle());
            TextView route = new TextView(MapsActivity.this);
            route.setText("Route: Western Route");
            TextView site_id = new TextView(MapsActivity.this);
            site_id.setText("Site ID: 45429");
            TextView site_name = new TextView(MapsActivity.this);
            site_name.setText("Site name: Aldermaston Ufton Crossing Relay Room");
            subInfoView.addView(asset_name);
            subInfoView.addView(route);
            subInfoView.addView(site_id);
            subInfoView.addView(site_name);
            infoView.addView(subInfoView);
        }
        else {
            ImageView infoImageView = new ImageView(MapsActivity.this);
            Drawable drawable = getResources().getDrawable(R.mipmap.asset_20);
//        Drawable drawable = getResources().getDrawable(android.R.drawable.ic_dialog_map);
            infoImageView.setImageDrawable(drawable);
            infoView.addView(infoImageView);

            LinearLayout subInfoView = new LinearLayout(MapsActivity.this);
            LinearLayout.LayoutParams subInfoViewParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            subInfoView.setOrientation(LinearLayout.VERTICAL);
            subInfoView.setLayoutParams(subInfoViewParams);

            TextView asset_name = new TextView(MapsActivity.this);
            asset_name.setText(marker.getTitle());
            TextView route = new TextView(MapsActivity.this);
            route.setText("Route: Western Route");
            TextView site_id = new TextView(MapsActivity.this);
            site_id.setText("Site ID: 36113");
            TextView site_name = new TextView(MapsActivity.this);
            site_name.setText("Site name: Midgham Relay Room");
            subInfoView.addView(asset_name);
            subInfoView.addView(route);
            subInfoView.addView(site_id);
            subInfoView.addView(site_name);
            infoView.addView(subInfoView);
        }

        return infoView;
    }
}
